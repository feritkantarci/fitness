---
name: ekat-yonetmeligi
description: >-
  Türkiye Elektrik Kuvvetli Akım Tesisleri (EKAT) Yönetmeliği, EDAŞ saha yönergeleri,
  0-1 kV Alçak Gerilim (AG) iç tesisat/pano/topraklama standartları, 1-36 kV Orta Gerilim (OG)
  trafo/hücre/koruma sistemleri, 5 altın güvenlik kuralı ve İş İzni (PTW) uzmanı.
---

# Elektrik Kuvvetli Akım Tesisleri (EKAT), AG (0-1 kV) ve OG (1-36 kV) Saha Mühendisliği Şartnamesi

Bu yetenek; Türkiye'de 30.11.2000 tarihli ve 24246 sayılı Resmî Gazete'de yayımlanan **Elektrik Kuvvetli Akım Tesisleri (EKAT) Yönetmeliği**, **Elektrik İç Tesisleri Yönetmeliği**, **Elektrik Tesislerinde Topraklamalar Yönetmeliği**, TEDAŞ tip projeleri ve Elektrik Dağıtım Şirketleri (EDAŞ) saha yönergelerini kapsayan kapsamlı teknik şartnamedir.

---

## 1. Hayati 5 Altın Güvenlik Kuralı (Altın Kural Zinciri)

Kuvvetli akım tesislerinde gerilimsiz ortamda yapılacak her türlü bakım, onarım ve montaj işlerinde aşağıdaki 5 kural **kesinlikle belirtilen sırayla** uygulanmalıdır. Sıralamanın ihlali veya bir adımın atlanması **hayati hata (fatal flaw)** kabul edilir:

```
[1. Gerilimi Kes] ➔ [2. Tekrar Açılmayı Önle (LOTO)] ➔ [3. Gerilim Yokluğunu Doğrula] ➔ [4. Toprakla ve Kısa Devre Et] ➔ [5. Alanı Sınırla ve Levhala]
```

1. **Gerilimi Kesmek (İzolasyon):** 
   - İlgili fider veya tesisin tüm besleme noktalarından enerjisi kesilir.
   - Önce yük kesilir (kesici açılır), ardından devre fiziki olarak yalıtılır (ayırıcı açılır).
2. **Tekrar Enerji Verilmesini Önlemek (LOTO - Kilitleme/Etiketleme):** 
   - Ayırıcıların manevra kolları kilitlenir, asma kilit (padlock) takılır.
   - "DİKKAT ÇALIŞMA VAR - ŞALTERİ AÇMAYINIZ" uyarı levhaları asılır.
   - Kumanda sigortaları sökülür, motor besleme şalterleri indirilir.
3. **Çalışılacak Yerde Gerilim Olmadığını Kontrol Etmek:** 
   - Gerilim seviyesine uygun ve kalibre edilmiş **Neon Stankası / Yüksek Gerilim Dedektörü** ile her 3 fazda ayrı ayrı gerilim yokluğu kontrol edilir.
   - Dedektörün sağlamlığı ölçümden hemen önce ve hemen sonra test edilmelidir.
4. **Topraklama ve Kısa Devre Yapmak:** 
   - İndüklenmiş veya kazaen verilebilecek gerilimleri toprağa akıtmak için seyyar topraklama donanımı takılır veya sabit topraklama ayırıcısı kapatılır.
   - **Kritik Kural:** Seyyar topraklama aparatında **ÖNCE toprak pensi topraklama barasına bağlanır, SONRA faz çeneleri iletkenlere takılır.** Sökerken işlem tam tersi sırada yapılır (Önce fazlar, en son toprak).
5. **Çalışma Yerini Emniyet Altına Almak ve Levhalandırmak:** 
   - Çalışma sahası reflektif emniyet şeritleri, ikaz barikatları ve bariyerlerle sınırlandırılır.
   - Komşu gerilimli kısımlar işaretlenir, fiziki tecrit perdeleri yerleştirilir.

---

## 2. Manevra Hiyerarşisi ve Sıralama Kuralları

### A. Devre Açma Manevrası (Enerji Kesme Sırası)
1. **Kesici (Disjonktör) Açılır:** Devre akımı yük altındayken güvenle kesilir.
2. **Kesicinin Açık Pozisyonu Doğrulanır:** Mekanik göstergeden (0/O konumu) teyit edilir.
3. **Ayırıcı (Seksiyonör) Açılır:** Akım geçmeyen devrede fiziki gözle görülür yalıtım sağlanır.
4. **Topraklama Ayırıcısı Kapatılır:** (Varsa hat/hücre topraklama ayırıcısı kilit serbest kalarak kapatılır).

> [!CAUTION]
> **Kesinlikle Yük Altında Ayırıcı Açılamaz!** Kesici açık konuma getirilmeden ayırıcıyı açmaya çalışmak elektrik ark patlamasına, personelin ölümüne ve şalt yangınına sebep olur.

### B. Devreye Alma Manevrası (Enerji Verme Sırası)
1. Çalışma ekibinin sahadan tamamen çekildiği ve tüm seyyar topraklamaların söküldüğü teyit edilir.
2. Varsa **Topraklama Ayırıcısı Açılır**.
3. **Ayırıcı (Seksiyonör) Kapatılır**.
4. **Kesici (Disjonktör) Kapatılır** ve yüke enerji verilir.

---

## 3. Yaklaşma ve Emniyet Mesafeleri (EKAT Madde 44)

Kuvvetli akım tesislerinde gerilim altındaki iletkenlere olan asgari emniyet yaklaşma mesafeleri:

| Gerilim Kademesi ($U_n$) | Minimum Emniyet Yaklaşma Mesafesi | Notlar |
| :--- | :--- | :--- |
| **0 – 1 kV (AG)** | **0.50 metre** | Yalıtkan eldiven/koruyucu zorunlu |
| **1 – 36 kV (OG - 34.5 kV)** | **2.00 metre** | Dağıtım şebekesi direk, köşk ve hücreler |
| **36 – 170 kV (YG - 154 kV)** | **3.00 metre** | TEİAŞ iletim hatları & indirici merkezler |
| **170 – 420 kV (ÇYG - 380 kV)** | **5.00 metre** | Büyük iletim enterkonnekte hatları |

### İş Makineleri ve Araçlar İçin Yaklaşma Sınırları
* Vinç, sepetli platform, ekskavatör, beton mikseri bomları havai hatlara yaklaşırken:
  * **OG (34.5 kV) hatlarda:** Asgari **3.5 metre**,
  * **YG (154-380 kV) hatlarda:** Asgari **5 - 8 metre** emniyet çemberi bırakılmalıdır.
  * Sahada operatöre refakat eden yetkili bir **Gözlemci/Nezaretçi (EKAT Belgeli)** bulunmalıdır.

### 34.5 kV Hat İletkenlerinin Yerden ve Yapılardan Yükseklikleri
* Geçit vermeyen engebeli arazide: **6 metre**
* Tarla, köy yolu, bahçelerde: **7 metre**
* Karayolu ve otoyol geçişlerinde: **9 metre**
* Binaların üzerinden havai hat geçirilemez; yapıların en yakın balkon/çatı kenarına yatay açıklık en az **3.5 metre** olmalıdır.

---

## 4. Alçak Gerilim (0 – 1 kV / AG) Mühendislik ve Tesis Standartları

Bu bölüm *Elektrik İç Tesisleri Yönetmeliği* ve *Elektrik Tesislerinde Topraklamalar Yönetmeliği* esaslarına dayanır.

### A. Kaçak Akım Koruma Röleleri (RCD / Artık Akım Anahtarları)
* **30 mA (Hayat Koruma):** Priz, banyo, mutfak ve son kullanıcıya temas eden tali linyelerde doğrudan dokunmaya karşı can emniyeti sağlar. Açma süresi $t \le 300\text{ ms}$ ($5 \times I_{\Delta n}$ akımında $\le 40\text{ ms}$).
* **300 mA (Yangın Koruma):** Ana dağıtım panosu girişinde izolasyon hatası kaynaklı elektrik yangınlarını önlemek için kullanılır.
* **Selektivite Kuralı:** Ana panodaki 300 mA kaçak akım rölesi **Gecikmeli (S Tipi - Selektif)** seçilerek, tali panodaki bir arızada tüm binanın elektriğinin kesilmesi önlenmelidir.
* **Sıfırlama Yasağı:** Nötr ile toprak iletkeninin prizde veya tali panoda köprülenmesi (sıfırlama) **kesinlikle yasaktır**. Nötr hattında kopma meydana geldiğinde cihaz gövdelerine doğrudan 230V gerilim vererek ölüme sebep olur.

### B. Topraklama Sistemleri ve Şebeke Tipleri
* **TN-S Sistemi:** Koruma iletkeni (PE) ve nötr iletkeni (N) trafodan yüke kadar tamamen ayrı çekilir (En güvenli ve modern sistem).
* **TN-C Sistemi:** Koruma ve nötr tek iletkende birleştirilmiştir (PEN). Kesiti en az $10\text{ mm}^2$ Cu veya $16\text{ mm}^2$ Al olmalıdır. Yangın riski nedeniyle yeni iç tesislerde kullanılamaz.
* **TT Sistemi:** Trafo nötrü dağıtım tarafında topraklanır, tüketicinin cihaz gövdeleri işletmeden bağımsız kendi temel/çubuk topraklamasına bağlanır. TT sistemde kaçak akım koruma rölesi (RCD) kullanımı **mecburidir**.
* **İzin Verilen Dokunma Gerilimi:** Alternatif akımda insan hayatı için izin verilen sınır dokunma gerilimi normal şartlarda $U_L \le 50\text{ V}$, ıslak ve nemli ortamlarda ise $U_L \le 25\text{ V}$'tur.

### C. Reaktif Güç Kompanzasyonu ve Harmonikler
* **EPDK Mevzuat Sınırları:**
  * Kurulu gücü $\ge 50\text{ kVA}$ olan aboneler için: Endüktif sınır **%20**, Kapasitif sınır **%15**.
  * Kurulu gücü $< 50\text{ kVA}$ olan aboneler için: Endüktif sınır **%33**, Kapasitif sınır **%20**.
* **Harmonik Filtreli Kompanzasyon:** Şebekede invertör, UPS, sürücü veya LED aydınlatma yoğunsa rezonansı önlemek için kondansatörlere seri bağlı **Harmonik Filtre Reaktörleri ($p = \%5.67, \%7, \%14$)** kullanılmalıdır.

### D. AG Kablo Kesiti ve Gerilim Düşümü ($\%e$) Sınırları
* **Maksimum İzin Verilen Gerilim Düşümü:**
  * Aydınlatma linyeleri için: Maksimum **%1.5**
  * Motor, priz ve güç linyeleri için: Maksimum **%3.0**
  * Özel trafolu tesislerde (Trafo ile ana pano arası): Maksimum **%5.0**
* **Formüller:**
  * Monofaze Devrelerde: $\%e = \frac{200 \cdot L \cdot P}{\kappa \cdot S \cdot U^2}$
  * Trifaze Devrelerde: $\%e = \frac{100 \cdot L \cdot P}{\kappa \cdot S \cdot U^2}$
  * ($\kappa$: Bakır için $56\text{ m}/(\Omega\cdot\text{mm}^2)$, Alüminyum için $35\text{ m}/(\Omega\cdot\text{mm}^2)$)

---

## 5. Orta Gerilim (1 kV – 36 kV / OG) Şebeke, Trafo ve Hücre Standartları

Bu bölüm TEDAŞ Dağıtım Şebekesi Tip Projeleri ve EDAŞ Şebeke İşletme Kriterlerine dayanır.

### A. 34.5 kV Dağıtım Transformatörleri ve Korumaları
* **Trafo Tipleri:** Yağlı (Hermetik veya Genleşme Depolu) ve Kuru Tip (Cast Resin / Epoksi Dökme Reçineli).
* **Mekanik Koruma Elemanları (Hermetik / Yağlı Trafo):**
  * **Buchholz Rölesi:** Trafo kazanı ile genleşme deposu arasına takılır. 1. Kademe (uyarı - yavaş gaz birikmesi), 2. Kademe (açma - şiddetli gaz dalgalanması / iç ark).
  * **Manyetik Yağ Seviye Göstergesi:** Yağ eksilmesinde uyarı/açma verir.
  * **Termometre (Termomanometre):** Sargı ve yağ sıcaklığı ($70^\circ\text{C}$ alarm, $85^\circ\text{C}$ açma).
  * **Basınç Emniyet Valfi:** İç basınç yükselmesinde açılarak kazanın patlamasını önler.
* **Trafo Sargı Bağlantısı:** Türkiye dağıtım şebekesinde yaygın standart **Dyn11** (Primer Üçgen, Sekonder Yıldız, Nötr dışarıda, 11 faz açısı saati).

### B. Modüler Hücre (RMU) Tipleri ve Fonksiyonları
* **Yük Ayırıcılı Giriş/Çıkış Hücresi:** Ring şebekede enerjiyi bölmek/aktarmak için SF6 gazlı yük ayırıcısı içerir. Yük altında açma/kapama yapabilir, kısa devre kesme kabiliyeti yoktur.
* **Vakumlu / SF6 Kesicili Çıkış Hücresi:** Fider korumasını sağlar, sekonder koruma rölesiyle kumanda edilir.
* **Trafo Koruma Hücresi:** 
  * $\le 1600\text{ kVA}$ güçlerde: OG Sigortalı Yük Ayırıcısı (HRC Yüksek Gerilim Sigortaları pimli tiptir; patladığında pimi fırlatarak ayırıcıyı mekanik olarak açtırır).
  * $> 1600\text{ kVA}$ güçlerde veya özel projelerde: Kesicili Trafo Koruma + Sekonder Röle.
* **Gerilim Ölçü Hücresi:** Baradaki gerilimi ölçmek ve sayaçlara bilgi vermek için gerilim transformatörleri (34.5/$\sqrt{3}$ / 0.1/$\sqrt{3}$ kV) içerir.
* **Mekanik İnterlock (Kilit Zinciri):**
  1. Kesici kapalıyken ayırıcı açılamaz.
  2. Ayırıcı açık değilken topraklama ayırıcısı kapatılamaz.
  3. Topraklama ayırıcısı kapalı değilken modüler hücrenin ön kapağı **açılamaz**.

### C. Sekonder Koruma Röleleri ve ANSI Kodları
OG dağıtım fiderlerinde kullanılan dijital koruma rölesi fonksiyonları:
* **ANSI 50:** Anlık Aşırı Akım Koruması (Definite Time / Instantaneous Overcurrent)
* **ANSI 51:** Zaman Gecikmeli Aşırı Akım Koruması (Inverse Definite Minimum Time - IDMT)
* **ANSI 50N / 51N:** Anlık ve Gecikmeli Toprak Hatası Koruması
* **ANSI 49:** Termik Aşırı Yük Koruması
* **Akım Trafosu Doğruluk Sınıfı:** Koruma için $5P10$ veya $5P20$ kullanılır (Anma akımının 10 veya 20 katında bile doymaya girmeden akımı sekondere doğru aktarmalıdır).

### D. XLPE Yeraltı Kabloları (20.3/35 kV) ve Başlık Yapımı
* **Kablo Katmanları:** Bakır/Al iletken $\rightarrow$ İç Yarı İletken $\rightarrow$ XLPE Yalıtkan $\rightarrow$ Dış Yarı İletken $\rightarrow$ Yarı İletken Şişen Bant $\rightarrow$ Bakır Ekran $\rightarrow$ PE Dış Kılıf.
* **Başlık Yapımı (Indoor/Outdoor):** Dış yarı iletken soyulurken XLPE yalıtkan yüzeyi çizilmemelidir. Elektriksel alan yoğunlaşmasını engellemek için **Stres Kontrol Tüpü (Stress Control)** ve mastik dolgusu şarttır.
* **Bakır Ekran Topraklaması:** Kablonun her iki ucundaki bakır ekran baraya sağlam şekilde topraklanmalıdır.
* **Testler:** İşletmeye almadan önce **VLF (0.1 Hz) Dayanım Testi** ve **Tan-Delta İzolasyon Kayıp Katsayısı Ölçümü** uygulanır.

---

## 6. EDAŞ Özel Saha Operasyon Yönergeleri

Dağıtım şebekesinde (KÖK, Kabin, Direk Tipi Trafo Postası - DTP) uygulanacak saha yönergeleri:

### A. DKM (Dağıtım Kumanda Merkezi) Koordinasyonu
* Sahada hiçbir kesici/ayırıcı **DKM (Scada Operatörü) onayı olmadan** açılamaz veya kapatılamaz.
* Manevra talimatı DKM tarafından kodlu ve yazılı olarak verilir, sahada telsiz/telefon üzerinden tekrarlanarak teyit edilir (*Üç Nokta Teyidi / Three-way Communication*).

### B. Direk Tipi Trafo Postası (DTP) Bakım ve Emniyet Protokolü
1. Önce direkteki AG ana dağıtım panosundaki termik şalter veya bıçaklı sigortalar açılarak trafo sekonderi yüksüz hale getirilir.
2. Direk üzerindeki OG Sigortalı Ayırıcı (seksiyonör) 36 kV yalıtkan manevra stankası ile güvenli mesafeden açılarak kilitlenir.
3. Trafo buşinglerinde gerilim kontrolü neon stanka ile yapılır.
4. AG ve OG klemenslerine kısa devre ve topraklama aparatı takılır.

---

## 7. İş İzni (Permit to Work - PTW) ve Saha Formları Mimarisi

Yüksek ve orta gerilim çalışmalarında doldurulması zorunlu form zinciri:

```
[İş İzni Talebi] ➔ [DKM Manevra Onayı] ➔ [5 Altın Kural Uygulama] ➔ [İş İzni Teslim] ➔ [Çalışma] ➔ [İş Bitim Tutanağı]
```

### 1. İş İzin Belgesi (PTW)
* **Lokasyon / Hücre No:** (Örn: SAMANDAĞ DM-04 Fider-3 Trafo Çıkışı)
* **İş İzni Veren:** İşletme Mühendisi / Vardiya Amiri (EKAT Belgeli).
* **Saha Sorumlusu:** 5 Altın kuralı sahada fiilen tatbik eden sorumlu (EKAT Belgeli).
* **Gözlemci / Nezaretçi:** Yaklaşma mesafelerini ve çevre güvenliğini denetleyen personel.

### 2. Manevra Formu
* Sıra No | Ekipman Kodu | Yapılacak Manevra (AÇ/KAPA) | DKM Onay Saati | Uygulama Saati | Manevrayı Yapan | Gözlemci

### 3. LOTO / Kilit Anahtarı Teslim Tutanağı
* Kilitlenen her ayırıcı için takılan asma kilidin anahtarı, çalışma tamamlanana kadar **Kilit Kutusu (Lockbox)** içinde muhafaza edilir.

---

## 8. Sınav & Saha Değerlendirme Taksonomisi (Hayati Hatalar)

Personel sınavlarında ve açık uçlu vaka analizlerinde şu hatalar **"Hayati Hata (Fatal Flaw)"** sayılır ve cevap doğrudan **0 PUAN (Başarısız)** ile sonuçlandırılır:

1. **Yük altında ayırıcı açmak** (Kesici açık konuma alınmadan ayırıcı manevrası yapmak).
2. **Topraklama sırasını ters işletmek** (Toprak pensini baraya bağlamadan faz çenelerini hatta takmak).
3. **Gerilim kontrolü yapmadan topraklama takmak** (Canlı hatta topraklama atarak ark patlamasına yol açmak).
4. **Kilitleme/Etiketleme (LOTO) yapmadan çalışmaya başlamak**.
5. **Nötr ile toprağı birleştirmek (Sıfırlama yapmak)** veya kaçak akım rölesini köprüleyerek devre dışı bırakmak.
6. **EKAT belgesi olmadan veya DKM onayı/PTW formu imzalanmadan OG hücresine/şebekeye müdahale etmek**.
