---
name: electrical-distribution-expert
description: >-
  Expert knowledge of electrical distribution grids (OG/AG), EDAŞ field operations,
  EKAT regulations, 5 Golden Safety Rules, switching/maneuver protocols, transformer substations,
  and power utility technical question authoring/evaluation.
---

# Electrical Distribution Grid & EKAT Domain Expert

This skill equips the agent with field-grade domain knowledge for Turkish Electricity Distribution Companies (EDAŞ / Toroslar EDAŞ), covering technical operations, Occupational Health & Safety (İSG), high/low voltage systems, and question assessment.

---

## 1. Regulatory & Safety Standards (EKAT & 5 Golden Rules)

All operations on Medium Voltage (OG - 34.5 kV / 15 kV) and Low Voltage (AG - 0.4 kV / 230-400 V) must strictly comply with the **5 Golden Safety Rules (5 Altın Kural)**:

1. **Enerjinin Her Taraftan Kesilmesi (Isolation):**
   - Manevra emrine göre kesicinin (kesici açılır) ve ardından ayırıcının (ayırıcı açılır) açılması.
   - Geri besleme ihtimali olan tüm OG/AG yönlerinin ve jeneratör bağlantılarının izole edilmesi.
2. **Tekrar Enerji Verilmesinin Önlenmesi (Lockout/Tagout - LOTO):**
   - Manevra kollarının kilitlenmesi, sigortaların sökülüp emniyete alınması, "DİKKAT ÇALIŞMA VAR ENERJİ VERME" levhalarının asılması.
3. **Tesisin Gerilimsiz Olduğunun Kontrolü (Voltage Absence Verification):**
   - Gerilim sınıfına uygun neon dedektör / stanka ile fazların tek tek kontrol edilmesi. Kontrolden önce dedektörün çalışırlığı test edilmelidir.
4. **Topraklama ve Kısa Devre Yapılması (Earthing & Short-Circuiting):**
   - Önce topraklama klipsi topraklama barasına bağlanır; ardından faz klipsleri stanka yardımıyla iletkenlere takılır (Sökülürken tersi sıra: önce fazlar, sonra toprak).
5. **Gerilim Altındaki Komşu Bölümlerin Korunması (Bariyer & Örtme):**
   - Çalışma alanına yakın canlı baraların yalıtkan örtü/bariyer ile kapatılması, emniyet şeritlerinin çekilmesi.

### Güvenli Emniyet / Yaklaşma Mesafeleri (EKAT Madde 60):
- **AG (0 - 1 kV):** Dokunma mesafesi (Yalıtkan eldiven/alet ile).
- **OG (1 kV - 36 kV / 34.5 kV):** Minimum **60 cm** emniyetli yaklaşma mesafesi.

---

## 2. Şebeke Donanımları & Terminolojisi

- **Dağıtım Transformatörleri:**
  - Hermetik Tip ve Genleşme Depolu Tip.
  - Silikajel (nem alıcı), Buchholz rölesi, termometre, buşingler (OG porselen buşing, AG buşing).
  - Kademe ayarı (boşta kademe değiştirici).
- **Anahtarlama Elemanları (Switchgear):**
  - **Kesici (Circuit Breaker):** Yük ve arıza (kısa devre) akımını açıp kapayabilen eleman (SF6 gazlı, Vakumlu).
  - **Ayırıcı (Disconnector):** Yüksüz devreyi açıp kapayan, gözle görülebilir fiziki ayırma sağlayan eleman.
  - **Yük Ayırıcısı (Switch Disconnector):** Normal yük akımını açabilen, kısa devre akımını kesemeyen eleman.
  - **Seksiyonör / Sigortalı Ayırıcı:** Havai hatlarda hat ayrımı ve branşman koruması.
  - **AG Panosu:** TMŞ (Termik Manyetik Şalter), NH Bıçaklı Sigorta (00, 1, 2, 3 boy), bara sistemi, sayaç ve akım trafoları.
- **Havai Hat & Yeraltı:**
  - İletkenler: Swallow (3/0 AWG), Raven (1/0 AWG), Pigeon (3/0 AWG), Aster, Rose.
  - İzolatörler: VHD mesnet izolatörler, kompozit askı/gergi izolatörleri, porselen zincir izolatör.
  - Yeraltı: XLPE kablolar (1x95, 1x150, 1x240 mm² vb.), kablo başlıkları (dâhili/harici tip) ve ek kutuları.

---

## 3. Kişisel Koruyucu Donanım (KKD) Standartları

- **Dielektrik Baret:** Çene bantlı, EN 397 / EN 50365 uyumlu.
- **Ark Koruyucu Vizör / Başlık:** EN 166 / GS-ET-29 elektrik ark patlamasına dayanıklı yüz siperi.
- **Yalıtkan Eldiven:** Sınıf 00 (500V), Sınıf 0 (1000V), Sınıf 4 (36 kV) - mekanik deri koruyucu üst eldivenle birlikte.
- **Manevra Stankası:** 36 kV anma gerilimine uygun, periyodik yalıtkanlık testleri yapılmış manevra stankası.
- **Paraşüt Tipi Emniyet Kemeri:** EN 361 & EN 358 standartlarında, şok emicili lanyarlı, direkte çift kollu emniyet kancası.

---

## 4. Soru Hazırlama & Yapay Zeka Değerlendirme Kuralları

1. **Soru Hazırlarken:**
   - Sorular sahadaki personelin karşılaştığı vaka senaryolarına dayandırılmalıdır (Örn: "Bir fırtına sonrası iletken kopması ihbarı geldiğinde...", "Hermetik trafo yağ sıcaklığı 85°C'ye ulaştığında...").
   - Çeldiriciler gerçek saha hatalarını yansıtmalıdır (Örn: "Önce ayırıcıyı açıp sonra kesiciyi açmak" ölümcül bir çeldiricidir).
2. **Açık Uçlu Cevapları Puanlarken:**
   - Personel enerji kesme adımında LOTO (kilitleme-etiketleme) ve gerilim kontrolü/topraklama yapmamışsa puanın en az %50'si kırılmalıdır (Hayati İSG kuralı).
   - Teknik terim doğruluğu (stanka, dedektör, topraklama takımı) denetlenmelidir.
