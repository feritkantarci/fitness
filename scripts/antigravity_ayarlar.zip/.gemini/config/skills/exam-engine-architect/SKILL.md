---
name: exam-engine-architect
description: >-
  Online assessment and exam lifecycle engine for field workforce applications.
  Enforces snapshot question isolation, server-timestamp based anti-time-drift countdowns,
  shift-based access windows, and manager-authorized retakes.
---

# Exam Engine Architecture Specification

This skill governs the lifecycle, timing, state machines, and data isolation rules for corporate field exams.

## 1. Exam Lifecycle State Machine

```
[DRAFT] -> [SCHEDULED] -> [WINDOW_OPEN] -> [IN_PROGRESS (per user)] -> [SUBMITTED] -> [GRADING] -> [PUBLISHED]
```

- **DRAFT:** Questions are assigned, modified, and scored.
- **SCHEDULED:** Start and end window dates/times are locked.
- **WINDOW_OPEN:** Workers within designated target units/regions can enter and start.
- **IN_PROGRESS:** Worker clicks "Sınava Başla". Individual timer starts counting down.
- **SUBMITTED:** Worker completes exam OR individual timer reaches 00:00 (auto-submit).
- **GRADING:** Multiple-choice scored automatically. Open-ended questions graded by authorized managers.
- **PUBLISHED:** Manager unlocks results. Only participants who took the exam can view report cards.

## 2. Snapshot Question Isolation (Immutable Exam Questions)

When questions from the central Question Bank are added to an Exam:
- They must be deep-cloned into an `exam_questions` array/collection for that specific `examId`.
- Any subsequent edit to the central Question Bank does NOT affect ongoing or historical exams.
- The exam creator can modify question text, choices, or points specifically for this exam without mutating the global question pool.
- Sınav kimliği: Sınav adına göre formatlanmış benzersiz kod (Örn: `SAMANDAG-SINAVI-01`).

## 3. Server-Timestamp Anti-Time-Drift Timer Architecture

Workers must NEVER be timed using only client device clock (`Date.now()` can be manipulated by changing phone time):
- When a worker clicks "Sınava Başla", record `startedAt: serverTimestamp()` on the server.
- Calculate `expiresAt = startedAt + examDurationMinutes * 60 * 1000`.
- Client continuously measures remaining time against `expiresAt - currentServerTimeDelta`.
- **Graceful Entry Window Rule:**
  - If exam window is `14:00 - 16:00` and exam duration is `20 minutes`:
  - If a worker starts at `15:59`, they get their full `20 minutes` (until `16:19`).
  - At `16:01`, no new attempts can be started.

## 4. Shift & Retake Management

- **Shift Re-opening:**
  - For units with rotating shifts (e.g. 14 workers on duty, 10 off duty):
  - The manager can reopen the exam window specifically for non-takers (`status == 'NOT_TAKEN'`).
- **Retake Authorization:**
  - Workers who have `SUBMITTED` cannot retake by default.
  - A manager can issue an explicit retake token (`allowRetake: true, retakeReason: '...'`), archiving the previous attempt and initializing a fresh session.
