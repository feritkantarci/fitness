---
name: offline-first-pwa-sync
description: >-
  Offline-first Progressive Web App (PWA) architecture and outbox synchronization for field workers.
  Manages IndexedDB local persistence, background network sync, and low-connectivity mobile resilience.
---

# Offline-First PWA Synchronization Specification

This skill dictates how field mobile applications handle intermittent connectivity, signal dropouts at electrical substations, and local data persistence.

## 1. Outbox Pattern for Exam Responses

When a field worker selects an answer or writes text:

1. **Immediate Local Commit (0ms):**
   - The answer is written to browser `IndexedDB` under `exam_outbox` table.
   - Record schema:
     ```typescript
     interface OutboxItem {
       id: string; // `${examId}_${questionId}_${attemptId}`
       examId: string;
       questionId: string;
       selectedOption?: string;
       textAnswer?: string;
       updatedAt: number;
       synced: boolean;
     }
     ```
   - UI reflects the choice instantly without waiting for network ACK.

2. **Background Sync Engine:**
   - A sync worker detects `navigator.onLine` and Firestore connection state.
   - Iterates pending items with `synced === false` and writes batch to Firestore `attempts/${attemptId}/answers`.
   - On successful write, updates `synced = true`.

3. **Status Indicator:**
   - Header displays subtle sync badge:
     - 🟢 *Tüm cevaplar kaydedildi* (All synced)
     - 🟡 *Kaydediliyor / Çevrimdışı hazır* (Pending offline sync)

## 2. PWA Asset Caching & Offline App Shell

- Cache-first strategy for static assets (fonts, icons, styles, logo).
- Stale-while-revalidate for exam metadata and question images.
- Questions and media for an active exam are preloaded into Cache Storage upon entering the waiting room so the exam can proceed even if GSM connection completely drops during the test.

## 3. Auto-Submit on Reconnect or Expiry

- If the countdown timer expires while offline, the app marks the local attempt as `PENDING_SUBMIT`.
- As soon as network connectivity is restored (even hours later), the service worker flushes the outbox and submits the final payload.
