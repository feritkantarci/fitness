---
name: ai-assessment-evaluator
description: >-
  Automated open-ended technical answer evaluation using Google Gemini AI.
  Evaluates field worker text responses against technical rubrics, suggests partial credit scores,
  identifies missing safety protocols, and generates manager feedback drafts.
---

# AI Open-Ended Assessment Evaluator Specification

This skill outlines how Google Gemini API evaluates subjective, text-based answers submitted by field personnel for open-ended technical scenarios.

## 1. Technical Evaluation Rubric

When an open-ended question is created, the engineer/creator defines:
- **Expected Criteria (Rubric Points):** Key procedures or keywords required (e.g., "1. Enerjiyi kesmek, 2. Kilitleme/Etiketleme (LOTO) yapmak, 3. Gerilim yokluğunu kontrol etmek, 4. Topraklamak").
- **Max Points:** (e.g. 20 points).

## 2. Gemini Prompt Architecture

```json
{
  "systemInstruction": "Sen Toroslar EDAŞ bünyesinde kıdemli bir Elektrik ve İSG Başmühendisisin. Sahadaki personelin verdiği açık uçlu cevabı, beklenen teknik kriterlerle kıyaslayarak adil, yapıcı ve teknik bir dille puanla.",
  "input": {
    "question": "Direk tipi trafo postasında bakım öncesi yapılması gereken ilk 4 emniyet kuralı nedir?",
    "rubric": [
      "1. AG ve OG sigortalarının/kesicilerinin açılması (Enerjinin kesilmesi)",
      "2. Kilitleme ve uyarı levhası asılması (LOTO)",
      "3. Neon stankası/gerilim kontrol cihazı ile gerilim yokluğunun kontrolü",
      "4. Topraklama ve kısa devre aparatlarının takılması"
    ],
    "maxScore": 20,
    "workerAnswer": "Önce enerjiyi kestik şalteri indirdik. Sonra kontrol ettik elektrik var mı diye. Sonra topraklama yaptık."
  }
}
```

## 3. Structured JSON Response Format

```json
{
  "suggestedScore": 15,
  "maxScore": 20,
  "evaluatedCriteria": [
    {"criterion": "Enerjinin kesilmesi", "fulfilled": true, "points": 5},
    {"criterion": "Kilitleme ve uyarı levhası (LOTO)", "fulfilled": false, "points": 0, "note": "LOTO veya levha asılmasından bahsedilmemiş."},
    {"criterion": "Gerilim kontrolü", "fulfilled": true, "points": 5},
    {"criterion": "Topraklama", "fulfilled": true, "points": 5}
  ],
  "missingProtocols": ["Kilitleme-Etiketleme (LOTO) prosedürü atlanmış."],
  "feedbackDraft": "Enerji kesme, kontrol ve topraklama adımları doğru ancak çalışma güvenliği için panoya mutlaka 'Çalışma Var Enerji Verme' levhası ve kilit takılmalıdır."
}
```

The evaluating manager can accept the AI recommendation with one click or adjust the score/feedback manually before publishing.
