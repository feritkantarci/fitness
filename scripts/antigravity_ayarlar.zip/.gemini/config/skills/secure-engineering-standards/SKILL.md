---
name: secure-engineering-standards
description: >-
  Production-grade defensive security engineering standards for web, PWA, Electron, and cloud applications.
  Enforces cryptographic salted credential hashing, strict CSP whitelisting, inline handler injection mitigation,
  CSV formula neutralization, DoS-bounded file imports, Electron IPC/navigation sandboxing, and least-privilege cloud database rules.
---

# Evrensel Güvenli Yazılım Geliştirme Standartları (Secure Engineering Standards)

Bu yetenek, tüm web, PWA, Electron masaüstü ve bulut (Firebase/Supabase/Cloud SQL) tabanlı projelerde mimari güvenlik, kimlik doğrulama, girdi doğrulama ve veri izolasyonu standartlarını zorunlu kılar.

---

## 1. Kimlik Doğrulama & Parola Güvenliği (Credentials & Password Hashing)
- **Açık Metin (Plaintext) Parola Yasağı:**
  - Kullanıcı şifreleri yerel depolamada (`localStorage`, `IndexedDB`) veya veritabanlarında ASLA açık metin olarak saklanamaz.
  - İstemci taraflı veya yerel kimlik doğrulamada Web Crypto API (`crypto.subtle.digest`) kullanılarak kullanıcıya özel benzersiz `salt` (ör. `crypto.getRandomValues(new Uint8Array(16))`) ile tuzlanmış **SHA-256** veya **PBKDF2** türetilmelidir.
- **Kimlik Bilgisi ve API Anahtarı İzolasyonu:**
  - `password`, `passwordHash`, `salt` veya kullanıcının üçüncü taraf özel API anahtarları (ör. Gemini API Key, OpenAI Key) asla istemci tarafından paylaşımlı/ortak bulut koleksiyonlarına (`Firestore`, `Supabase` ortak tabloları) kontrolsüzce yazdırılamaz.
  - Bulut senkronizasyonu yapılırken hassas alanlar bir `syncFilter` / `sanitizeBeforeCloudSync` adımından geçirilmelidir.

---

## 2. XSS ve Dinamik Olay İşleyici (Event Handler) Enjeksiyonu Koruması
- **Öznitelik İçi (Attribute Context) Kaçış Tuzağı:**
  - HTML özniteliklerinde (ör. `onclick="..."`) dinamik değişken veya kullanıcı girdisi basılırken klasik `escapeHTML` (`' -> &#039;`) YETERSİZDİR; çünkü tarayıcı HTML ayrıştırıcısı JavaScript çalıştırılmadan önce `&#039;` kodunu tek tırnağa geri çözer.
  - Dinamik veya kullanıcı kontrollü string parametreler HTML özniteliklerine aktarılırken mutlaka:
    ```javascript
    // Güvenli dinamik argüman aktarımı:
    `onclick="handleAction(decodeURIComponent('${encodeURIComponent(param)}'))"`
    ```
    veya `data-*` öznitelikleri (`dataset`) ve `addEventListener` kullanılmalıdır.
- **İçerik Kaçışları (Text Escaping):**
  - Kullanıcıdan gelen tüm metinler DOM'a basılırken ya `escapeHTML()` kullanılmalı ya da doğrudan `element.textContent` ile atanmalıdır.
  - Markdown dönüştürücülerde ham HTML etiketleri (`<`, `>`, `"`, `'`) ayrıştırmadan önce temizlenmelidir.

---

## 3. İçerik Güvenlik Politikası (Content Security Policy - CSP)
- **Joker Karakter (`*`) Yasağı:**
  - CSP meta etiketlerinde veya HTTP başlıklarında `https://*` veya `connect-src https://*` gibi denetimsiz joker kurallar kullanılamaz.
  - Yalnızca projenin zorunlu olduğu harici CDN'ler, API'ler ve veritabanı alan adları (örn: `*.googleapis.com`, `cdnjs.cloudflare.com`) açıkça listelenmelidir.
- **Temel Güvenlik Başlıkları:**
  - HTML içinde `X-Content-Type-Options: nosniff` ve `Referrer-Policy: strict-origin-when-cross-origin` tanımlanmalıdır.

---

## 4. Electron & Masaüstü Uygulama Sertleştirmesi
- **macOS Yetkilendirmeleri (Entitlements):**
  - `com.apple.security.cs.allow-dyld-environment-variables` gibi dinamik kütüphane enjeksiyonuna izin veren yetkiler ASLA verilmemelidir.
  - `package.json` yapılandırmasında `"hardenedRuntime": true` aktif edilmelidir.
- **Gezinme ve Pencere İzolasyonu:**
  - `mainWindow.webContents.on('will-navigate', ...)` ile yerel `file:` şeması dışındaki yönlendirmeler engellenmelidir.
  - `mainWindow.webContents.setWindowOpenHandler(...)` ile yetkisiz pencere açılması reddedilmeli (`action: 'deny'`), izin verilen web linkleri `shell.openExternal` ile sistem tarayıcısına yönlendirilmelidir.
  - `contextIsolation: true` ve `nodeIntegration: false` her zaman korunmalıdır.

---

## 5. CSV Formül Enjeksiyonu & Dosya İçe Aktarım Güvenliği
- **CSV Formula Injection:**
  - CSV dışa aktarımlarında hücre içeriği `=`, `+`, `-`, `@`, `\t`, `\r` ile başlıyorsa Excel/Sheets formül çalıştırma açığını engellemek için başına tek tırnak (`'`) eklenmelidir:
    ```javascript
    function sanitizeCsvCell(str) {
      if (typeof str !== 'string') return str;
      if (/^[\=\+\-\@\t\r]/.test(str)) return "'" + str;
      return str;
    }
    ```
- **DoS & Şema Doğrulaması:**
  - Kullanıcıdan JSON veya veri dosyası içe aktarılırken dosya boyutu sınırı (ör. max 2 MB) konulmalı ve dosya içeriği şema filtresinden geçirilmeden sisteme kaydedilmemelidir.

---

## 6. Veritabanı En Az Yetki Kuralı (Least Privilege DB Rules)
- **Açık/Güvensiz Veritabanı Yasağı:**
  - Firebase Firestore, Supabase RLS veya Realtime DB kuralları `allow read, write: if true;` şeklinde açık bırakılamaz.
  - Koleksiyon bazlı erişim modeli tanımlanmalı; sistem yapılandırmaları (`system_config`), kullanıcı kimlik verileri ve hassas koleksiyonlar istemci tarafından yazmaya kapatılmalı veya kimliği doğrulanmış kullanıcı sahipliğine (`request.auth.uid == userId`) bağlanmalıdır.
