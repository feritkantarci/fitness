---
name: competency-gap-analytics
description: >-
  Competency matrix, error taxonomy, and training needs analysis (TNA) for corporate exams.
  Calculates category-based proficiency, radar/spider charts, and department-level skill gap reporting.
---

# Competency & Skill Gap Analytics Specification

This skill governs how individual and group exam results are analyzed, converted into competency matrices, and visualized for executive decision-making.

## 1. Competency Scoring Model

Every question in the system is mapped to a mandatory category:
- **İSG** (Occupational Health & Safety)
- **ELEKTRİK / ŞEBEKE** (Grid Operations, High/Low Voltage, Transformers)
- **İDARİ & MEVZUAT** (Administrative, Procedures, Work Orders)
- *Custom categories dynamically defined by the organization*

### Formula
For each user attempt $u$ and category $c$:
$$\text{Score}(u, c) = \frac{\sum_{q \in Q_c} \text{EarnedPoints}(u, q)}{\sum_{q \in Q_c} \text{MaxPoints}(q)} \times 100$$

### Competency Thresholds
- **$\ge 80\%$ : Yetkin / Güçlü (Proficient)** - Green
- **$60\% - 79\%$ : Kabul Edilebilir (Acceptable)** - Amber
- **$< 60\%$ : Kritik Eğitim Eksiği (Critical Gap)** - Red alert, flags for mandatory retraining.

## 2. Visualizations
- **Radar (Spider) Chart:** For individual worker report card showing multi-axis category strength.
- **Unit Comparison Bar Chart:** Comparative analysis between field units (e.g. *Samandağ AOB* vs *İskenderun AOB* vs *Antakya Bakım*).
- **Error Taxonomy / Worst Questions:** Ranking questions with the highest failure rates across the entire organization to pinpoint systematic knowledge gaps.
