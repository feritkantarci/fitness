#import <ApplicationServices/ApplicationServices.h>
#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[]) {
    if (argc < 3) {
        NSRect f = [[NSScreen mainScreen] frame];
        printf("Screen points: %.0fx%.0f\n", f.size.width, f.size.height);
        return 0;
    }
    double x = atof(argv[1]);
    double y = atof(argv[2]);
    CGPoint pt = CGPointMake(x, y);
    CGEventRef move = CGEventCreateMouseEvent(NULL, kCGEventMouseMoved, pt, kCGMouseButtonLeft);
    CGEventRef down = CGEventCreateMouseEvent(NULL, kCGEventLeftMouseDown, pt, kCGMouseButtonLeft);
    CGEventRef up = CGEventCreateMouseEvent(NULL, kCGEventLeftMouseUp, pt, kCGMouseButtonLeft);
    CGEventPost(kCGHIDEventTap, move);
    usleep(50000);
    CGEventPost(kCGHIDEventTap, down);
    usleep(50000);
    CGEventPost(kCGHIDEventTap, up);
    CFRelease(move);
    CFRelease(down);
    CFRelease(up);
    return 0;
}
