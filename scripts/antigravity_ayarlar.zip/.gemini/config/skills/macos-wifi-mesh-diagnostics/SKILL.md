---
name: macos-wifi-mesh-diagnostics
description: >-
  macOS Wi-Fi physical layer diagnostics, TP-Link Deco Mesh optimization,
  Avast WebShield proxy bottleneck resolution, and native Quartz CGEvent GUI
  automation for Deco.app. Use whenever diagnosing Wi-Fi speed, latency,
  bufferbloat, router/Mesh settings, or controlling Deco on macOS.
---

# macOS Wi-Fi & TP-Link Deco Mesh Diagnostics Skill

## 1. Pre-Flight Hardware & Link Audit (`en0`)
Run these commands first to establish the physical baseline before proposing any router changes:
```zsh
system_profiler SPHardwareDataType | grep -E "Model Name|Model Identifier|Chip"
system_profiler SPAirPortDataType | grep -A 35 "Current Network Information:"
netstat -I en0 -b
scutil --dns | grep nameserver | head -n 5
```
- **Hardware Ceiling Check (`Mac14,7` / `BCM4378` `0x14E4, 0x4378`):** Supports up to `802.11ax 5 GHz @ 80 MHz` (`2x2 MIMO`; no `160 MHz` or `6 GHz`). Maximum real TCP throughput is **~65–70% of `Transmit Rate`** (e.g., `864 Mbps` PHY at `MCS 8` = `~590–600 Mbps` real download).
- **Sticky Client Check:** Compare `Current Network Information` RSSI against `Other Local Wi-Fi Networks` on the same channel. macOS sticks to a weaker AP (e.g. `-61 dBm` on secondary `GİRİŞ2`) until RSSI drops below `-75 dBm`, ignoring a `-50 dBm` main AP (`GİRİŞ Ana`) nearby. Rebooting the secondary AP or toggling `en0` moves the Mac onto the main AP.
- **Speed Test Caveat:** `networkQuality -s` tests against overseas Apple CDN nodes (`~86 ms` RTT), which caps throughput lower than local domestic servers. Validate actual domestic ISP speed via `speedtest.net` (local TR server).

## 2. Local Network Extension & Antivirus Proxy Bottleneck Check
Always check if a third-party network extension or antivirus proxy is throttling gigabit traffic:
```zsh
systemextensionsctl list
/Applications/Avast.app/Contents/Backend/utils/com.avast.cmd ctl status
```
- **Avast Selective Shield Rule:** `WebShield` (`com.avast.proxy`), `Firewall` (`com.avast.filter`), and `SecureDNS` bottleneck gigabit Wi-Fi to `~270–350 Mbps` due to user-space proxy inspection. Keep **`FileShield` enabled** for malware protection (`0%` network impact) and disable the network proxy shields:
```zsh
osascript -e 'do shell script "/Applications/Avast.app/Contents/Backend/utils/com.avast.cmd ctl stop WebShield; /Applications/Avast.app/Contents/Backend/utils/com.avast.cmd ctl stop Firewall; /Applications/Avast.app/Contents/Backend/utils/com.avast.cmd ctl stop SecureDNS; /Applications/Avast.app/Contents/Backend/utils/com.avast.cmd ctl start FileShield" with administrator privileges'
```

## 3. TP-Link Deco Mesh Rules (4-Node Setup: `GİRİŞ Ana`, `Salon`, `Yatak odası`, `GİRİŞ2`)
1. **Never Assume ISP Tier:** Do not guess a `500 Mbps` tier when tests cap at `~425 Mbps`. Always verify the actual ISP tier (e.g. `1000/50 Mbps`).
2. **Channel Width Invariant:**
   - `2.4 GHz`: **`20 MHz`** (prevents co-channel overlap)
   - `5 GHz`: **`160 MHz`** (MANDATORY: wireless satellite Decos rely on 5 GHz for wireless backhaul across walls; dropping to `80 MHz` cuts Mesh throughput in half)
   - `6 GHz`: **`320 MHz`**
3. **QoS Invariant on Gigabit Lines:** Keep Deco **QoS OFF** on 1000 Mbps connections so Hardware NAT remains active.

## 4. Automated GUI Control of `Deco.app` on macOS
`Deco.app` runs as an iOS wrapper (`/private/var/folders/.../Wrapper/Deco.app`) and does not expose standard AppleScript UI elements. Control it via Quartz `CGEventPost` (`1440x900` screen points) using [deco_click.m](./scripts/deco_click.m) + `screencapture -x`:
```zsh
clang -framework ApplicationServices -framework Cocoa ~/.gemini/config/skills/macos-wifi-mesh-diagnostics/scripts/deco_click.m -o /tmp/deco_click
/tmp/deco_click <x_point> <y_point>
```
